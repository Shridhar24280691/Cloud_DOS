#!/bin/bash
rm -rf /home/ec2-user/car_app/*
