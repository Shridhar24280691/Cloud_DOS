#!/bin/bash
rm -rf /var/www/car_app/*
mkdir -p /var/www/car_app
