#!/bin/bash
cd /home/ec2-user/car_app
pip3 install -r requirements.txt
