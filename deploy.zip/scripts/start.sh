#!/bin/bash
echo "Nothing to start — Elastic Beanstalk manages the app."
exit 0
