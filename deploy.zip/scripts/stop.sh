#!/bin/bash
pkill -f "manage.py"
