#!/bin/bash
echo "No service to stop"
exit 0
